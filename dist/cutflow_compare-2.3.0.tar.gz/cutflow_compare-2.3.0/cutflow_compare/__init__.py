"""cutflow_compare package root."""

__all__ = ["__version__"]
__version__ = "2.3.0"
